from datetime import datetime
#import requests
import boto3
#import csv
#import json
#import os
#from binance.client import Client
#from binance.exceptions import BinanceAPIException, BinanceOrderException

key = datetime.now().strftime("%m-%d-%Y")
DB_NAME = 'orderbookBinance_' + key
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(DB_NAME)

response = table.query(
    ScanIndexForward=False,
    Limit=2
)
print(response)

#client = Client('UW4GQ5AODRwGQ8ZhQ7U2VwQKDJm0mnkW5pMScrQdsABjYkg8LVuLk5uUqbbeE4rT', 'kdqVlKMAcFIImqR6apvFxY4RSjaFZAXjLFim6DbXRbVIZunQnz2Wd5IEZb94my3m')
#client.API_URL = 'https://testnet.binance.vision/api'
#print(client.get_account())
#try:
#    #buy_order = client.create_order(symbol='ETHUSDT', side='BUY', type='MARKET', quantity=1)
#    buy_order = 1
#    print(buy_order)
#except BinanceAPIException as e:
#    # error handling goes here
#    print(e)
#except BinanceOrderException as e:
#    # error handling goes here
#    print(e)

#print(buy_order)